# Offline installatie (firewall)

De map `wheels/` bevat Windows **Python 3.15** (64-bit) packages.

## Installeren

In de projectmap, met venv geactiveerd:

```bat
python -m pip install --no-index --find-links=wheels -r requirements.txt
```

Of dubbelklik / run:

```bat
install_offline.bat
```

Of handmatig de kern:

```bat
python -m pip install --no-index --find-links=wheels bleak keyboard python-dotenv edge-tts fastapi uvicorn aiohttp openai websockets
```

## Belangrijk

- Wheels zijn voor **Windows 64-bit + CPython 3.15**.
- Andere Python-versie (3.12) → deze binary wheels passen niet; download dan op een PC mét internet met:
  ```bat
  pip download -r requirements.txt -d wheels
  ```
- Geen internet nodig tijdens `pip install --no-index ...`.

## Starten

```bat
python main.py -c strict_domme --web
```
