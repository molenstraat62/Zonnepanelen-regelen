@echo off
echo Offline install Coyote AI Edger (Windows)
echo.

if not exist wheels (
  echo Map "wheels" niet gevonden.
  exit /b 1
)

python -m pip install --no-index --find-links=wheels -r requirements.txt
if errorlevel 1 (
  echo.
  echo requirements.txt deels mislukt — probeer handmatig:
  echo   python -m pip install --no-index --find-links=wheels bleak keyboard python-dotenv edge-tts fastapi uvicorn aiohttp openai websockets
)

echo.
echo Klaar. Start met:
echo   python main.py -c strict_domme --web
pause
