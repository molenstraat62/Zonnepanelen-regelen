from .base import Character
from .strict_domme import STRICT_DOMME
from .teasing import TEASING
from .clinical import CLINICAL
from .sadistic import SADISTIC
from .caring_intense import CARING_INTENSE
from .json_loader import load_json_characters

CHARACTERS = {
    STRICT_DOMME.id: STRICT_DOMME,
    TEASING.id: TEASING,
    CLINICAL.id: CLINICAL,
    SADISTIC.id: SADISTIC,
    CARING_INTENSE.id: CARING_INTENSE,
}

# Merge custom JSON characters
CHARACTERS.update(load_json_characters())

def get_character(char_id: str) -> Character:
    if char_id not in CHARACTERS:
        raise ValueError(f"Unknown character '{char_id}'. Available: {list(CHARACTERS.keys())}")
    return CHARACTERS[char_id]

def list_characters() -> list[Character]:
    return list(CHARACTERS.values())
