"""
Base character definition.
Every AI persona inherits from this.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Dict, Any


@dataclass
class Character:
    id: str
    name: str
    description: str

    # How the AI talks / thinks
    system_prompt: str

    # Intensity behaviour
    ramp_aggression: float = 1.0      # >1 = faster ramp back after edge
    edge_drop_factor: float = 0.22    # how hard it drops when close
    desense_bias: float = 1.0         # higher = compensates desensitization more
    mean_chance: float = 0.08         # chance bias for mean events
    force_allowed: bool = False       # may push past edge into forced orgasm

    # Soft / hard limits this character respects
    soft_limit_factor: float = 0.85    # relative to calibrated base
    hard_limit_factor: float = 1.15    # absolute ceiling relative to base

    # Preferred patterns (coyopy mode names)
    preferred_patterns_a: List[str] = field(default_factory=lambda: ["waves", "breath"])
    preferred_patterns_b: List[str] = field(default_factory=lambda: ["breath", "pulse"])

    # How often the AI speaks (0.0 – 1.0)
    talkativeness: float = 0.4

    # TTS voice hint
    tts_voice: str = "nl-NL-ColetteNeural"

    # Extra flavour
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "ramp_aggression": self.ramp_aggression,
            "edge_drop_factor": self.edge_drop_factor,
            "force_allowed": self.force_allowed,
            "talkativeness": self.talkativeness,
            "tags": self.tags,
        }
