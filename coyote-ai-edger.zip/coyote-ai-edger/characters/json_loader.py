"""
Load characters from JSON files in characters/custom/
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Dict

from .base import Character

log = logging.getLogger(__name__)
CUSTOM_DIR = Path(__file__).parent / "custom"


def load_json_characters() -> Dict[str, Character]:
    chars: Dict[str, Character] = {}
    if not CUSTOM_DIR.exists():
        return chars

    for path in CUSTOM_DIR.glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            c = Character(
                id=data["id"],
                name=data.get("name", data["id"]),
                description=data.get("description", ""),
                system_prompt=data.get("system_prompt", "Je bent een AI die een e-stim sessie bestuurt."),
                ramp_aggression=float(data.get("ramp_aggression", 1.0)),
                edge_drop_factor=float(data.get("edge_drop_factor", 0.22)),
                desense_bias=float(data.get("desense_bias", 1.0)),
                mean_chance=float(data.get("mean_chance", 0.08)),
                force_allowed=bool(data.get("force_allowed", False)),
                soft_limit_factor=float(data.get("soft_limit_factor", 0.85)),
                hard_limit_factor=float(data.get("hard_limit_factor", 1.15)),
                preferred_patterns_a=data.get("preferred_patterns_a", ["waves", "breath"]),
                preferred_patterns_b=data.get("preferred_patterns_b", ["breath", "pulse"]),
                talkativeness=float(data.get("talkativeness", 0.4)),
                tts_voice=data.get("tts_voice", "nl-NL-ColetteNeural"),
                tags=data.get("tags", []),
            )
            chars[c.id] = c
            log.info("Loaded custom character: %s", c.id)
        except Exception as e:
            log.warning("Failed to load %s: %s", path.name, e)
    return chars
