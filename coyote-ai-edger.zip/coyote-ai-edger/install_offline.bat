@echo off
echo Offline install for Python 3.12 (Windows)
python --version
python -m pip install --no-index --find-links=.\wheels -r requirements.txt
if errorlevel 1 (
  echo Fallback core packages...
  python -m pip install --no-index --find-links=.\wheels bleak keyboard python-dotenv edge-tts fastapi uvicorn openai websockets aiohttp
)
pause
