@echo off
echo Offline install Python 3.12 Windows
python --version
echo.
echo [1/2] winrt + core binary...
python -m pip install --no-index --find-links=.\wheels winrt-runtime aiohttp websockets pydantic-core
python -m pip install --no-index --find-links=.\wheels winrt-windows-devices-bluetooth winrt-windows-devices-bluetooth-advertisement winrt-windows-devices-bluetooth-genericattributeprofile winrt-windows-devices-enumeration winrt-windows-devices-radios winrt-windows-foundation winrt-windows-foundation-collections winrt-windows-storage-streams
echo.
echo [2/2] rest...
python -m pip install --no-index --find-links=.\wheels bleak keyboard python-dotenv edge-tts fastapi uvicorn openai starlette anyio click h11 httpx httpcore idna certifi pydantic yarl multidict frozenlist aiosignal aiohappyeyeballs attrs propcache sniffio tabulate tqdm colorama typing-extensions
echo.
echo Done. Test:
echo   python -c "import bleak, fastapi, aiohttp, winrt.runtime; print('ok')"
pause
