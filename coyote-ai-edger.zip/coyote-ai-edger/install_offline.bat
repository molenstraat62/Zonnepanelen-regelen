@echo off
echo Offline install – Python 3.12 Windows
python --version
echo.

echo Installing winrt (bleak on Windows)...
python -m pip install --no-index --find-links=.\wheels winrt-runtime
python -m pip install --no-index --find-links=.\wheels winrt-windows-devices-bluetooth winrt-windows-devices-bluetooth-advertisement winrt-windows-devices-bluetooth-genericattributeprofile winrt-windows-devices-enumeration winrt-windows-devices-radios winrt-windows-foundation winrt-windows-foundation-collections winrt-windows-storage-streams

echo Installing requirements...
python -m pip install --no-index --find-links=.\wheels -r requirements.txt

echo.
echo Test:
python -c "import bleak, fastapi, uvicorn, websockets, aiohttp; print('OK')"
pause
