"""
Lovense Edge 2 (and other Lovense toys) control via local Connect API.

Requires Lovense Connect / Remote app running on the same machine or network.
Default port: 20010 (or check the app).

API docs (community): GET/POST http://127.0.0.1:20010/...
"""

from __future__ import annotations

import logging
from typing import Optional

log = logging.getLogger(__name__)


class LovenseEdge:
    def __init__(self, base_url: str = "http://127.0.0.1:20010"):
        self.base_url = base_url.rstrip("/")
        self.connected = False
        self.toy_id: Optional[str] = None
        self._session = None

    async def connect(self) -> bool:
        try:
            import aiohttp
        except ImportError:
            log.error("aiohttp required for Lovense: pip install aiohttp")
            return False

        self._session = aiohttp.ClientSession()
        try:
            # GetToys
            async with self._session.get(f"{self.base_url}/GetToys") as resp:
                if resp.status != 200:
                    log.warning("Lovense Connect not reachable at %s", self.base_url)
                    return False
                data = await resp.json()
                # data format varies; try common shapes
                toys = data.get("data") or data.get("toys") or data
                if isinstance(toys, dict):
                    # pick first toy
                    for tid, info in toys.items():
                        self.toy_id = tid
                        name = info.get("name", tid) if isinstance(info, dict) else tid
                        log.info("Lovense toy found: %s (%s)", name, tid)
                        break
                if not self.toy_id:
                    log.warning("No Lovense toys found. Is the app connected to a toy?")
                    return False
                self.connected = True
                return True
        except Exception as e:
            log.warning("Lovense connect failed: %s", e)
            return False

    async def set_vibrate(self, strength: float):
        """strength 0.0 – 1.0 (or 0-20 depending on API)."""
        if not self.connected or not self._session:
            return
        # Lovense often uses 0-20
        v = max(0, min(20, int(strength * 20)))
        try:
            url = f"{self.base_url}/Vibrate"
            params = {"v": v}
            if self.toy_id:
                params["t"] = self.toy_id
            async with self._session.get(url, params=params) as resp:
                pass
        except Exception as e:
            log.debug("Lovense vibrate error: %s", e)

    async def stop(self):
        await self.set_vibrate(0)

    async def disconnect(self):
        await self.stop()
        if self._session:
            await self._session.close()
        self.connected = False
        log.info("Lovense disconnected")
