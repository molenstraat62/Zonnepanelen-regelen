# Coyote AI Edger

Volledig karakter-gedreven AI-systeem voor de **DG-Lab Coyote V3**, met optionele Lovense Edge 2, twee-weg spraak, funscript, web dashboard en custom JSON-karakters.

## Features

| Feature | Flag / gebruik |
|---------|----------------|
| **Karakters** (built-in + JSON) | `-c strict_domme` / zet JSON in `characters/custom/` |
| **Session Goals** | `-g edge_only` / `edges_then_denial` / `forced` / `training` / `endurance` |
| **Calibratie** | standaard aan, `--no-cal` om over te slaan |
| **Twee-weg spraak** | `--conversation` |
| **Keyword speech** | `--speech` |
| **Civet** | `--civet` |
| **Lovense Edge 2** | `--lovense` (Lovense Connect app nodig) |
| **Funscript** | `--funscript pad/naar/file.funscript` |
| **Web dashboard** | `--web` → http://127.0.0.1:8765 |
| **TTS** | standaard aan (edge-tts) |
| **LLM** | `OPENAI_API_KEY` of offline rules |
| **Session memory + logging** | automatisch in `memory/` en `logs/` |
| **Mood, events, patterns** | automatisch |

## Snel starten

```bash
python -m venv .venv
source .venv/bin/activate

# Core deps (geen coyopy nodig – pure bleak controller)
pip install -r requirements.txt

# Als playsound problemen geeft op Windows:
#   pip install playsound==1.2.2
# pygame is optioneel (vaak lastig op Python 3.13+)

# Optioneel: coyopy vanaf GitHub (niet verplicht)
# pip install "coyopy @ git+https://github.com/thalarion210/coyopy.git"

python main.py --list-characters

# Klassieke sessie
python main.py -c teasing -g edges_then_denial --edges 4

# Met dashboard + conversatie
python main.py -c strict_domme --conversation --web

# Funscript
python main.py --funscript ./scripts/demo.funscript --no-cal

# Coyote + Lovense
python main.py -c caring_intense --lovense --web
```

## Eigen karakter maken (JSON)

Kopieer `characters/custom/_template.json` naar bijvoorbeeld `characters/custom/mijn_dom.json` en pas aan:

```json
{
  "id": "mijn_dom",
  "name": "Mijn Dom",
  "description": "...",
  "system_prompt": "Je bent ...",
  "ramp_aggression": 1.1,
  "edge_drop_factor": 0.2,
  "force_allowed": false,
  "soft_limit_factor": 0.85,
  "hard_limit_factor": 1.15,
  "preferred_patterns_a": ["waves", "climb"],
  "preferred_patterns_b": ["breath", "pulse"],
  "talkativeness": 0.5,
  "tts_voice": "nl-NL-ColetteNeural",
  "tags": ["custom"]
}
```

Daarna gewoon: `python main.py -c mijn_dom`

## Twee-weg conversatie

```bash
python main.py --conversation
```

Je praat → Vosk transcribeert → LLM antwoordt in character → TTS spreekt het uit.
Werkt het best met een Vosk-model in de map `model/`.

## Web dashboard

```bash
python main.py --web
# open http://127.0.0.1:8765
```

Live: power A/B, phase, edges, mood, character, goal, laatste AI-regel.

## Lovense Edge 2

1. Start de **Lovense Connect** (of Remote) app en verbind de Edge 2.
2. Zorg dat de lokale API aan staat (meestal poort 20010).
3. Run met `--lovense`.

De trilling volgt grotendeels de intensiteit van Coyote kanaal A.

## Funscript

Ondersteunt standaard `.funscript` (actions met `at` in ms en `pos` 0–100).
Wordt gemapt naar power op beide kanalen (of één kanaal).

## Doelen

| Goal | Betekenis |
|------|-----------|
| `edge_only` | Altijd terugtrekken bij edge |
| `edges_then_denial` | Na N edges → denial |
| `forced` | Na N edges forceren (alleen als karakter het toestaat) |
| `training` | Lange gecontroleerde randen |
| `endurance` | Zo lang mogelijk net onder de edge |

## Mappen

```
characters/           built-in + custom/*.json
core/                 brain, mood, events, goals, memory, tts, conversation, funscript…
devices/              lovense.py
feedback/             keyboard, speech, civet
web/                  FastAPI dashboard
logs/                 per-sessie logs
memory/               session history
```

## Veiligheid

- Globale hard limits + per-karakter soft/hard factors
- ESC / Ctrl+C / spraak “stop” → direct 0
- Calibratie heeft eigen max
- Test altijd eerst laag

Gebruik op eigen risico.
