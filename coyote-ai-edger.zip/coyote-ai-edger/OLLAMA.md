# Lokaal AI-model (Ollama) – offline achter firewall

OpenAI cloud werkt niet achter jouw firewall. Gebruik **Ollama** op dezelfde PC.

## 1. Ollama installeren

Download Windows installer: https://ollama.com/download

## 2. Model downloaden (waar wél internet is)

```bat
ollama pull llama3.2
```

Kleiner/sneller:
```bat
ollama pull llama3.2:1b
ollama pull qwen2.5:3b
```

Zonder net op de target-PC: kopieer `%USERPROFILE%\.ollama` mee.

## 3. Laten draaien

Ollama start meestal als app/service. Check:

```bat
ollama list
curl http://127.0.0.1:11434/api/tags
```

## 4. Coyote AI Edger config

```python
LLM_BACKEND = "ollama"
LLM_BASE_URL = "http://127.0.0.1:11434/v1"
LLM_MODEL = "llama3.2"
```

Geen OPENAI_API_KEY nodig.

## 5. Test

```bat
python -c "from openai import OpenAI; c=OpenAI(base_url='http://127.0.0.1:11434/v1', api_key='ollama'); print(c.chat.completions.create(model='llama3.2', messages=[{'role':'user','content':'zeg hallo in 5 woorden'}]).choices[0].message.content)"
```
