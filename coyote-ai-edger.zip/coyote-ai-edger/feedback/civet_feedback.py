"""
Civet (DG-Lab pressure / edging sensor) feedback.
Device name: 47L124000

Protocol:
  Service  0x180C
  Write    0x150A
  Notify   0x150B

Start reporting (17 bytes):
  0x50 0x01 0xD0 + 14×0x00

D0 notification:
  pressure = int.from_bytes(data[8:10], "little") / 100.0  → kPa
"""

from __future__ import annotations

import asyncio
import logging
import struct
from typing import Callable, Optional

from config import (
    CIVET_NAME_PREFIX,
    CIVET_EDGE_THRESHOLD_KPA,
    CIVET_HYSTERESIS,
)

log = logging.getLogger(__name__)

# Full UUIDs (Bluetooth base)
SERVICE_UUID = "0000180c-0000-1000-8000-00805f9b34fb"
WRITE_UUID   = "0000150a-0000-1000-8000-00805f9b34fb"
NOTIFY_UUID  = "0000150b-0000-1000-8000-00805f9b34fb"

# 50 command: start pressure reporting
START_REPORT_CMD = bytes([0x50, 0x01, 0xD0] + [0x00] * 14)
STOP_REPORT_CMD  = bytes([0x50, 0x01, 0x00] + [0x00] * 14)


class CivetFeedback:
    def __init__(
        self,
        on_close: Callable[[bool], None],
        edge_threshold_kpa: float = CIVET_EDGE_THRESHOLD_KPA,
        hysteresis: float = CIVET_HYSTERESIS,
    ):
        self.on_close = on_close
        self.edge_threshold = edge_threshold_kpa
        self.hysteresis = hysteresis
        self._client = None
        self._running = False
        self._last_pressure = 0.0
        self._is_close = False
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    @property
    def last_pressure(self) -> float:
        return self._last_pressure

    @property
    def is_close(self) -> bool:
        return self._is_close

    async def connect(self, timeout: float = 10.0) -> bool:
        """Scan and connect to Civet. Returns True on success."""
        try:
            from bleak import BleakScanner, BleakClient
        except ImportError:
            log.error("bleak required for Civet: pip install bleak")
            return False

        log.info("Scanning for Civet (%s)…", CIVET_NAME_PREFIX)
        log.info("Tip: press the power button 5× if it does not appear.")

        devices = await BleakScanner.discover(timeout=timeout)
        target = None
        for d in devices:
            name = d.name or ""
            if name.startswith(CIVET_NAME_PREFIX):
                target = d
                break

        if not target:
            log.warning("Civet not found. Make sure it is on and in pairing mode.")
            return False

        self._client = BleakClient(target.address)
        await self._client.connect()
        log.info("Civet connected: %s (%s)", target.name, target.address)

        # Subscribe to notifications first
        await self._client.start_notify(NOTIFY_UUID, self._notification_handler)

        # Start pressure reporting
        await self._client.write_gatt_char(WRITE_UUID, START_REPORT_CMD, response=False)
        log.info("Civet pressure reporting started (threshold=%.1f kPa)", self.edge_threshold)

        self._running = True
        self._loop = asyncio.get_running_loop()
        return True

    def _notification_handler(self, sender, data: bytearray):
        """Parse D0 pressure report (called from BLE thread)."""
        if not data or data[0] != 0xD0:
            return
        if len(data) < 10:
            return

        # bytes 8-9 little-endian int16 → kPa
        raw = int.from_bytes(data[8:10], "little", signed=True)
        pressure = raw / 100.0
        self._last_pressure = pressure

        # Hysteresis to avoid flickering
        if not self._is_close and pressure >= self.edge_threshold:
            self._is_close = True
            self._safe_callback(True)
            log.info("Civet EDGE  pressure=%.2f kPa", pressure)
        elif self._is_close and pressure < (self.edge_threshold - self.hysteresis):
            self._is_close = False
            self._safe_callback(False)

    def _safe_callback(self, is_close: bool):
        """Call on_close safely from any thread."""
        try:
            if self._loop and self._loop.is_running():
                self._loop.call_soon_threadsafe(self.on_close, is_close)
            else:
                self.on_close(is_close)
        except Exception as e:
            log.debug("Civet callback error: %s", e)

    async def disconnect(self):
        self._running = False
        if self._client and self._client.is_connected:
            try:
                await self._client.write_gatt_char(WRITE_UUID, STOP_REPORT_CMD, response=False)
            except Exception:
                pass
            try:
                await self._client.stop_notify(NOTIFY_UUID)
            except Exception:
                pass
            await self._client.disconnect()
            log.info("Civet disconnected")
