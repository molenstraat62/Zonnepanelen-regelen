"""
Keyboard feedback.
Hold SPACE = "I am close to the edge"
E        = "enough" (during calibration)
ESC      = emergency stop
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Callable, Optional

from config import KEYBOARD_EDGE_KEY, KEYBOARD_STOP_KEY, KEYBOARD_ENOUGH_KEY

log = logging.getLogger(__name__)


class KeyboardFeedback:
    def __init__(
        self,
        on_close: Callable[[bool], None],
        on_stop: Callable[[], None],
        on_enough: Optional[Callable[[], None]] = None,
    ):
        self.on_close = on_close
        self.on_stop = on_stop
        self.on_enough = on_enough
        self._running = False
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        try:
            import keyboard
        except ImportError:
            log.error("keyboard package missing. pip install keyboard")
            return

        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        log.info("Keyboard feedback active – SPACE=close, E=enough, ESC=stop")

    def stop(self) -> None:
        self._running = False

    def _loop(self) -> None:
        import keyboard

        last_close = False
        last_enough = False
        while self._running:
            try:
                close = keyboard.is_pressed(KEYBOARD_EDGE_KEY)
                if close != last_close:
                    self.on_close(close)
                    last_close = close

                enough = keyboard.is_pressed(KEYBOARD_ENOUGH_KEY)
                if enough and not last_enough and self.on_enough:
                    self.on_enough()
                last_enough = enough

                if keyboard.is_pressed(KEYBOARD_STOP_KEY):
                    log.warning("ESC pressed → emergency stop")
                    self.on_stop()
                    break
            except Exception as e:
                log.debug("Keyboard poll error: %s", e)

            time.sleep(0.04)
