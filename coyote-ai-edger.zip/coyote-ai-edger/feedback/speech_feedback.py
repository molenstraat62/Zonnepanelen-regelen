"""
Speech feedback using Vosk (offline).
Keywords: edge, close, now, genoeg, te veel, stop, ...
"""

from __future__ import annotations

import json
import logging
import queue
import threading
import time
from typing import Callable, Optional

from config import SPEECH_MODEL_PATH, SPEECH_SAMPLE_RATE, SPEECH_KEYWORDS

log = logging.getLogger(__name__)


class SpeechFeedback:
    def __init__(
        self,
        on_close: Callable[[bool], None],
        on_stop: Callable[[], None],
        on_enough: Optional[Callable[[], None]] = None,
    ):
        self.on_close = on_close
        self.on_stop = on_stop
        self.on_enough = on_enough
        self._running = False
        self._thread: threading.Thread | None = None
        self._close_timeout = 2.8  # seconds after last edge keyword
        self._last_edge = 0.0

    def start(self) -> None:
        self._running = True
        self._thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._thread.start()
        log.info("Speech feedback started (Vosk)")

    def stop(self) -> None:
        self._running = False

    def _listen_loop(self) -> None:
        try:
            import sounddevice as sd
            from vosk import Model, KaldiRecognizer
        except ImportError:
            log.error("Vosk / sounddevice not installed. "
                      "pip install vosk sounddevice && download a model to ./model")
            return

        try:
            model = Model(SPEECH_MODEL_PATH)
        except Exception as e:
            log.error("Could not load Vosk model from '%s': %s", SPEECH_MODEL_PATH, e)
            log.error("Download from https://alphacephei.com/vosk/models "
                      "(e.g. vosk-model-small-en-us-0.15 or nl model)")
            return

        rec = KaldiRecognizer(model, SPEECH_SAMPLE_RATE)
        rec.SetWords(True)

        audio_q: queue.Queue = queue.Queue()

        def audio_callback(indata, frames, time_info, status):
            if status:
                log.debug("Audio status: %s", status)
            audio_q.put(bytes(indata))

        try:
            with sd.RawInputStream(
                samplerate=SPEECH_SAMPLE_RATE,
                blocksize=8000,
                dtype="int16",
                channels=1,
                callback=audio_callback,
            ):
                log.info("Microphone listening… say 'edge' / 'genoeg' / 'stop'")
                while self._running:
                    try:
                        data = audio_q.get(timeout=0.5)
                    except queue.Empty:
                        # timeout → clear close state if needed
                        if time.time() - self._last_edge > self._close_timeout:
                            self.on_close(False)
                        continue

                    if rec.AcceptWaveform(data):
                        result = json.loads(rec.Result())
                        text = (result.get("text") or "").lower().strip()
                        if text:
                            self._handle_text(text)
                    else:
                        partial = json.loads(rec.PartialResult())
                        ptext = (partial.get("partial") or "").lower().strip()
                        if ptext:
                            self._handle_text(ptext, partial=True)

        except Exception as e:
            log.error("Speech loop error: %s", e)

    def _handle_text(self, text: str, partial: bool = False) -> None:
        # Edge / close
        edge_words = {"edge", "close", "now", "almost", "i am close", "edge now"}
        if any(w in text for w in edge_words):
            self._last_edge = time.time()
            self.on_close(True)
            if not partial:
                log.info("Speech: EDGE detected (%s)", text)

        # Enough (calibration)
        enough_words = {"genoeg", "te veel", "enough", "too much"}
        if any(w in text for w in enough_words):
            if self.on_enough:
                self.on_enough()
            if not partial:
                log.info("Speech: ENOUGH detected (%s)", text)

        # Stop
        stop_words = {"stop", "stoppen", "abort", "uit"}
        if any(w in text for w in stop_words):
            log.warning("Speech: STOP detected (%s)", text)
            self.on_stop()
