"""
Configuration for Coyote AI Edger
"""

# --- Safety limits (global software hard caps) ---
MAX_POWER_A = 45
MAX_POWER_B = 40
SOFT_LIMIT_A = 35
SOFT_LIMIT_B = 30

# --- Starting / base powers (overwritten by calibration) ---
BASE_POWER_A = 18
BASE_POWER_B = 14

# --- Adaptive behaviour defaults (overridden by character) ---
RAMP_BACK_SECONDS = 22.0
EDGE_DROP_FACTOR = 0.22
DESENSE_UP_RATE = 0.0024
DESENSE_DOWN_RATE = 0.0006
DESENSE_MAX = 1.55

# --- Update rates ---
CONTROL_LOOP_HZ = 7

# --- Feedback keys ---
KEYBOARD_EDGE_KEY = "space"
KEYBOARD_STOP_KEY = "esc"
KEYBOARD_ENOUGH_KEY = "e"

# --- Calibration ---
CALIBRATION_ENABLED = True
CALIBRATION_START_POWER = 8
CALIBRATION_STEP = 1.2
CALIBRATION_STEP_INTERVAL = 4.0
CALIBRATION_MAX_TEST = 40

# --- Patterns ---
DEFAULT_MODE_A = "waves"
DEFAULT_MODE_B = "breath"
DEFAULT_FREQ_A = 28
DEFAULT_FREQ_B = 18
DEFAULT_SPEED = 0.85

# --- Device names ---
COYOTE_NAME_PREFIX = "47L121000"
CIVET_NAME_PREFIX = "47L124000"

# --- Civet ---
CIVET_EDGE_THRESHOLD_KPA = 8.0
CIVET_BASELINE_KPA = 1.5
CIVET_HYSTERESIS = 1.5

# --- Speech (Vosk) ---
SPEECH_MODEL_PATH = "model"
SPEECH_SAMPLE_RATE = 16000
SPEECH_KEYWORDS = [
    "edge", "close", "now", "almost",
    "genoeg", "te veel", "stop", "stoppen",
]

# --- Character & session defaults ---
DEFAULT_CHARACTER = "strict_domme"
DEFAULT_GOAL = "edge_only"          # edge_only | edges_then_denial | forced | training | endurance
DEFAULT_TARGET_EDGES = 3

# --- TTS ---
TTS_ENABLED = True
TTS_VOICE = "nl-NL-ColetteNeural"   # edge-tts neural Dutch voices

# --- LLM ---
# backend: "ollama" (lokaal, default) | "openai" (cloud) | "auto"
LLM_BACKEND = "ollama"
# Ollama OpenAI-compatible endpoint
LLM_BASE_URL = "http://127.0.0.1:11434/v1"
# Model name in Ollama (bijv. llama3.2, mistral, qwen2.5)
LLM_MODEL = "llama3.2"
# Alleen nodig bij LLM_BACKEND=openai
# OPENAI_API_KEY via environment
