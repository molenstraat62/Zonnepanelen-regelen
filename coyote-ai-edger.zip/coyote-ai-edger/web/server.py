"""
Local web dashboard + command channel for Coyote AI Edger.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Set

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse

log = logging.getLogger(__name__)

app = FastAPI(title="Coyote AI Edger Dashboard")
clients: Set[WebSocket] = set()
state: Dict[str, Any] = {
    "power_a": 0,
    "power_b": 0,
    "close": False,
    "edges": 0,
    "phase": "idle",
    "character": "",
    "character_id": "",
    "goal": "",
    "mood_intensity": 0,
    "desense": 1.0,
    "last_line": "",
    "running": False,
    "cal_mode": "both",
    "connected": False,
    "characters": [],
    "goals": [
        {"id": "edge_only", "name": "Alleen edgen"},
        {"id": "edges_then_denial", "name": "Edges daarna denial"},
        {"id": "forced", "name": "Forced"},
        {"id": "training", "name": "Training"},
        {"id": "endurance", "name": "Endurance"},
    ],
    "cal_modes": [
        {"id": "both", "name": "Beide kanalen"},
        {"id": "a_only", "name": "Alleen A"},
        {"id": "b_only", "name": "Alleen B"},
        {"id": "alternate", "name": "A/B om en om"},
        {"id": "pattern_focus", "name": "Met pattern-wissel"},
    ],
}

# Callback set by main.py: async def handle(cmd: str, payload: dict)
_command_handler: Optional[Callable] = None


def set_command_handler(handler: Callable):
    global _command_handler
    _command_handler = handler


def update_state(**kwargs):
    state.update(kwargs)


async def broadcast(msg: dict):
    dead = []
    for ws in clients:
        try:
            await ws.send_json(msg)
        except Exception:
            dead.append(ws)
    for ws in dead:
        clients.discard(ws)


async def push_state():
    await broadcast({"type": "state", "data": state})


@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    clients.add(ws)
    await ws.send_json({"type": "state", "data": state})
    try:
        while True:
            raw = await ws.receive_json()
            cmd = raw.get("cmd")
            payload = raw.get("payload") or {}
            if not cmd:
                continue
            log.info("Web cmd: %s %s", cmd, payload)
            if _command_handler:
                try:
                    result = _command_handler(cmd, payload)
                    if asyncio.iscoroutine(result):
                        await result
                except Exception as e:
                    log.exception("Command handler error: %s", e)
                    await ws.send_json({"type": "error", "message": str(e)})
            await push_state()
    except WebSocketDisconnect:
        clients.discard(ws)


@app.get("/", response_class=HTMLResponse)
async def index():
    html_path = Path(__file__).parent / "index.html"
    return HTMLResponse(html_path.read_text(encoding="utf-8"))
