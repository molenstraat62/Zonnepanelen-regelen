"""
Small safety helpers.
"""

import logging
import signal
import sys

log = logging.getLogger(__name__)


def install_sigint_handler(stop_callback):
    """Make Ctrl+C cleanly stop the session."""
    def handler(sig, frame):
        log.warning("SIGINT received – stopping cleanly")
        stop_callback()
        sys.exit(0)

    signal.signal(signal.SIGINT, handler)
