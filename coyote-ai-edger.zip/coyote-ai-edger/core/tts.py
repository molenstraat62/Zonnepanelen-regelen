"""
Text-to-speech so the AI can talk back.
Uses edge-tts (online, high quality). Audio playback tries several backends
so pygame is optional (important on very new Python versions on Windows).
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
import tempfile
from pathlib import Path
from typing import Optional

log = logging.getLogger(__name__)


def _play_mp3_sync(path: str) -> bool:
    """Try several ways to play an mp3. Returns True on success."""
    # 1) pygame
    try:
        import pygame
        if not pygame.mixer.get_init():
            pygame.mixer.init()
        pygame.mixer.music.load(path)
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy():
            pygame.time.wait(50)
        return True
    except Exception as e:
        log.debug("pygame play failed: %s", e)

    # 2) playsound
    try:
        from playsound import playsound
        playsound(path)
        return True
    except Exception as e:
        log.debug("playsound failed: %s", e)

    # 3) Windows: powershell / Media.SoundPlayer won't do mp3 easily;
    #    use start with default associated app (non-blocking-ish)
    if sys.platform == "win32":
        try:
            os.startfile(path)  # type: ignore[attr-defined]
            # rough wait – user can still hear it
            import time
            time.sleep(2.5)
            return True
        except Exception as e:
            log.debug("os.startfile failed: %s", e)

    # 4) macOS
    if sys.platform == "darwin":
        try:
            import subprocess
            subprocess.run(["afplay", path], check=False)
            return True
        except Exception as e:
            log.debug("afplay failed: %s", e)

    # 5) Linux: paplay / mpg123 / ffplay
    for cmd in (
        ["mpg123", "-q", path],
        ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", path],
        ["paplay", path],
    ):
        try:
            import subprocess
            subprocess.run(cmd, check=False)
            return True
        except Exception:
            continue

    return False


class TTS:
    def __init__(self, voice: str = "nl-NL-ColetteNeural", enabled: bool = True):
        self.voice = voice
        self.enabled = enabled
        self._queue: asyncio.Queue = asyncio.Queue()
        self._worker_task: Optional[asyncio.Task] = None

    async def start(self):
        if not self.enabled:
            return
        self._worker_task = asyncio.create_task(self._worker())
        log.info("TTS started (voice=%s)", self.voice)

    async def stop(self):
        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass

    async def say(self, text: str):
        if not self.enabled or not text.strip():
            return
        await self._queue.put(text.strip())

    async def _worker(self):
        while True:
            text = await self._queue.get()
            try:
                await self._speak(text)
            except Exception as e:
                log.warning("TTS error: %s", e)
            finally:
                self._queue.task_done()

    async def _speak(self, text: str):
        try:
            import edge_tts
        except ImportError:
            log.warning("edge-tts not installed – AI zou zeggen: %s", text)
            return

        with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as f:
            tmp = f.name

        try:
            communicate = edge_tts.Communicate(text, self.voice)
            await communicate.save(tmp)
            ok = await asyncio.to_thread(_play_mp3_sync, tmp)
            if not ok:
                log.info("AI zegt: %s  (geen audio-backend gevonden)", text)
        finally:
            Path(tmp).unlink(missing_ok=True)
