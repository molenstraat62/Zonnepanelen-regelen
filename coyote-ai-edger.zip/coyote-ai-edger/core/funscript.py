"""
Funscript / timeline player.
Maps funscript actions (at=ms, pos=0-100) to Coyote power over time.
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import List, Optional, Tuple

log = logging.getLogger(__name__)


class FunscriptPlayer:
    def __init__(self, controller, channel: str = "a"):
        self.controller = controller
        self.channel = channel.lower()  # "a", "b", or "both"
        self.actions: List[Tuple[float, float]] = []  # (time_sec, pos_0_100)
        self.playing = False
        self.start_time = 0.0
        self.loop = False
        self.duration = 0.0

    def load(self, path: str) -> bool:
        p = Path(path)
        if not p.exists():
            log.error("Funscript not found: %s", path)
            return False
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            actions = data.get("actions", [])
            self.actions = sorted(
                [(a["at"] / 1000.0, float(a["pos"])) for a in actions],
                key=lambda x: x[0],
            )
            self.duration = self.actions[-1][0] if self.actions else 0
            log.info("Funscript loaded: %d actions, %.1fs", len(self.actions), self.duration)
            return True
        except Exception as e:
            log.error("Funscript parse error: %s", e)
            return False

    def start(self, loop: bool = False):
        if not self.actions:
            log.warning("No funscript loaded")
            return
        self.loop = loop
        self.playing = True
        self.start_time = time.time()
        log.info("Funscript playing (loop=%s)", loop)

    def stop(self):
        self.playing = False
        self.controller.set_power(0, 0)

    def tick(self) -> bool:
        """Call every control loop. Returns False when finished (and not looping)."""
        if not self.playing or not self.actions:
            return False

        elapsed = time.time() - self.start_time
        if elapsed > self.duration:
            if self.loop:
                self.start_time = time.time()
                elapsed = 0
            else:
                self.playing = False
                return False

        # Interpolate position
        pos = self._interpolate(elapsed)
        # Map 0-100 pos → power (scale can be adjusted)
        power = pos * 0.7  # leave some headroom

        if self.channel == "a":
            self.controller.set_power(power, 0)
        elif self.channel == "b":
            self.controller.set_power(0, power)
        else:
            self.controller.set_power(power, power * 0.85)

        return True

    def _interpolate(self, t: float) -> float:
        if t <= self.actions[0][0]:
            return self.actions[0][1]
        if t >= self.actions[-1][0]:
            return self.actions[-1][1]
        for i in range(len(self.actions) - 1):
            t0, p0 = self.actions[i]
            t1, p1 = self.actions[i + 1]
            if t0 <= t <= t1:
                if t1 == t0:
                    return p1
                frac = (t - t0) / (t1 - t0)
                return p0 + (p1 - p0) * frac
        return 0.0
