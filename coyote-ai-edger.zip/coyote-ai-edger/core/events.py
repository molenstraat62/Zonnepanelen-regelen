"""
Random / triggered session events.
"""

from __future__ import annotations

import logging
import random
import time
from typing import Callable, Optional

log = logging.getLogger(__name__)


class EventEngine:
    def __init__(self, pattern_manager, edger, logger=None):
        self.pm = pattern_manager
        self.edger = edger
        self.logger = logger
        self.last_event = 0.0
        self.min_gap = 45.0  # seconds between random events

    def maybe_trigger(self, mood_meanness: float = 0.2, force: bool = False) -> Optional[str]:
        now = time.time()
        if not force and (now - self.last_event) < self.min_gap:
            return None

        roll = random.random()
        if not force and roll > (0.08 + mood_meanness * 0.25):
            return None

        # Choose event
        events = [
            self._spike,
            self._long_drop,
            self._pattern_chaos,
            self._silence,
        ]
        if mood_meanness > 0.4:
            events.append(self._overstim_burst)

        event_fn = random.choice(events)
        name = event_fn()
        self.last_event = now
        if self.logger:
            self.logger.event("special_event", name=name)
        return name

    def _spike(self) -> str:
        log.info("EVENT: sudden spike")
        self.pm.random_mean_pattern()
        # temporary power boost handled by caller / mood
        return "spike"

    def _long_drop(self) -> str:
        log.info("EVENT: long drop / almost stop")
        self.edger.on_feedback(True)  # force a deep drop
        return "long_drop"

    def _pattern_chaos(self) -> str:
        log.info("EVENT: pattern chaos")
        self.pm.maybe_auto_switch(force=True, aggression=2.0)
        return "pattern_chaos"

    def _silence(self) -> str:
        log.info("EVENT: sudden silence (psychological)")
        self.edger.controller.set_power(0, 0)
        return "silence"

    def _overstim_burst(self) -> str:
        log.info("EVENT: overstim burst")
        self.pm.random_mean_pattern()
        return "overstim_burst"
