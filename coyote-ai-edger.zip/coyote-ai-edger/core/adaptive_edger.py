"""
Adaptive edging + habituation (gewenning) compensation.
Longer high intensity → desense_factor rises → effective power increases
to keep perceived intensity more stable.
"""

from __future__ import annotations

import time
import logging
from dataclasses import dataclass, field

from config import (
    BASE_POWER_A,
    BASE_POWER_B,
    RAMP_BACK_SECONDS,
    EDGE_DROP_FACTOR,
    DESENSE_UP_RATE,
    DESENSE_DOWN_RATE,
    DESENSE_MAX,
    SOFT_LIMIT_A,
    SOFT_LIMIT_B,
)

log = logging.getLogger(__name__)


@dataclass
class AdaptiveEdger:
    controller: object
    base_a: float = BASE_POWER_A
    base_b: float = BASE_POWER_B
    soft_a: float = SOFT_LIMIT_A
    soft_b: float = SOFT_LIMIT_B
    edge_drop_factor: float = EDGE_DROP_FACTOR

    close: bool = False
    last_edge_time: float = field(default_factory=time.time)
    desense_factor: float = 1.0
    current_a: float = 0.0
    current_b: float = 0.0
    running: bool = False
    # Habituation tracking
    high_time: float = 0.0          # seconds spent in high intensity this session
    session_start: float = field(default_factory=time.time)
    edge_count: int = 0

    def set_bases(self, base_a: float, base_b: float, soft_a: float | None = None, soft_b: float | None = None):
        self.base_a = base_a
        self.base_b = base_b
        if soft_a is not None:
            self.soft_a = soft_a
        if soft_b is not None:
            self.soft_b = soft_b
        log.info("Bases A=%.1f B=%.1f softA=%.1f softB=%.1f", self.base_a, self.base_b, self.soft_a, self.soft_b)

    def on_feedback(self, is_close: bool) -> None:
        if is_close and not self.close:
            log.info("EDGE → drop")
            self.last_edge_time = time.time()
            self.edge_count += 1
            # After many edges, body often less sensitive → nudge desense up
            if self.edge_count >= 2:
                self.desense_factor = min(DESENSE_MAX, self.desense_factor + 0.02)
        self.close = is_close

    def _compute_targets(self) -> tuple[float, float]:
        now = time.time()
        if self.close:
            target_a = max(3.0, self.base_a * self.edge_drop_factor)
            target_b = max(2.0, self.base_b * self.edge_drop_factor)
        else:
            elapsed = now - self.last_edge_time
            ramp = min(1.0, elapsed / RAMP_BACK_SECONDS)
            ramp = ramp * ramp
            target_a = self.base_a * ramp * self.desense_factor
            target_b = self.base_b * ramp * self.desense_factor

        target_a = min(target_a, self.soft_a * max(1.0, self.desense_factor * 0.92))
        target_b = min(target_b, self.soft_b * max(1.0, self.desense_factor * 0.92))
        # still respect absolute soft as ceiling grows slowly with desense
        target_a = min(target_a, self.soft_a * 1.25)
        target_b = min(target_b, self.soft_b * 1.25)
        return target_a, target_b

    def _update_desense(self, dt: float) -> None:
        """
        Gewenning: time at high intensity + session length → higher factor.
        Recovery when intensity is low.
        """
        high = self.current_a > self.base_a * 0.65
        if high and not self.close:
            self.high_time += dt
            # accelerate after ~2 min cumulative high
            rate = DESENSE_UP_RATE
            if self.high_time > 120:
                rate *= 1.6
            if self.high_time > 300:
                rate *= 1.3
            self.desense_factor = min(DESENSE_MAX, self.desense_factor + rate * (dt * 7))
        else:
            # slow recovery
            self.desense_factor = max(1.0, self.desense_factor - DESENSE_DOWN_RATE * (dt * 7))

        # long session baseline creep (very slow)
        session_min = (time.time() - self.session_start) / 60.0
        if session_min > 8 and not self.close:
            self.desense_factor = min(DESENSE_MAX, self.desense_factor + 0.00015)

    def tick(self) -> None:
        if not self.running:
            return
        dt = 1.0 / 7.0
        target_a, target_b = self._compute_targets()
        alpha = 0.28
        self.current_a = (1 - alpha) * self.current_a + alpha * target_a
        self.current_b = (1 - alpha) * self.current_b + alpha * target_b
        self._update_desense(dt)
        self.controller.set_power(self.current_a, self.current_b)

    def start(self) -> None:
        self.running = True
        self.current_a = 0
        self.current_b = 0
        self.last_edge_time = time.time()
        self.session_start = time.time()
        self.high_time = 0.0
        self.desense_factor = 1.0
        self.edge_count = 0
        log.info("Edger start base A=%.1f B=%.1f", self.base_a, self.base_b)

    def stop(self) -> None:
        self.running = False
        self.controller.emergency_stop()
        log.info("Edger stop (desense was %.2f, high_time=%.0fs)", self.desense_factor, self.high_time)
