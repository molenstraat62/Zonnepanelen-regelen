"""
Session logging to console + rotating file.
"""

from __future__ import annotations

import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

log = logging.getLogger(__name__)


class SessionLogger:
    def __init__(self, log_dir: str = "logs"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.events: List[Dict[str, Any]] = []
        self.start_time = time.time()
        self.file_path = self.log_dir / f"session_{self.session_id}.jsonl"

        # Also attach a file handler for normal logs
        fh = logging.FileHandler(self.log_dir / f"session_{self.session_id}.log", encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
        logging.getLogger().addHandler(fh)

        log.info("Session logger started → %s", self.file_path)

    def event(self, kind: str, **data):
        entry = {
            "ts": time.time(),
            "elapsed": round(time.time() - self.start_time, 1),
            "kind": kind,
            **data,
        }
        self.events.append(entry)
        with open(self.file_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        log.info("EVENT %s %s", kind, data)

    def edge(self, pressure: float | None = None):
        self.event("edge", pressure=pressure)

    def power(self, a: float, b: float):
        self.event("power", a=round(a, 1), b=round(b, 1))

    def pattern(self, a: str, b: str):
        self.event("pattern", a=a, b=b)

    def say(self, text: str, character: str = ""):
        self.event("say", text=text, character=character)

    def goal(self, goal: str):
        self.event("goal", goal=goal)

    def summary(self) -> Dict[str, Any]:
        edges = sum(1 for e in self.events if e["kind"] == "edge")
        duration = time.time() - self.start_time
        return {
            "session_id": self.session_id,
            "duration_sec": round(duration, 1),
            "edges": edges,
            "events": len(self.events),
        }
