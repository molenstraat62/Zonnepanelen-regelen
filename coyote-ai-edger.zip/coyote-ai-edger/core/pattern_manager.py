"""
Pattern switching for Coyote channels.
Can be driven by the character, the LLM, or manually.
"""

from __future__ import annotations

import logging
import random
import time
from typing import List, Optional

log = logging.getLogger(__name__)

# Common coyopy / Coyote V3 style pattern names
AVAILABLE_PATTERNS = [
    "waves", "breath", "pulse", "climb", "hold",
    "random", "tickle", "sting", "whip", "throb",
]


class PatternManager:
    def __init__(self, controller, preferred_a: List[str] | None = None, preferred_b: List[str] | None = None):
        self.controller = controller
        self.preferred_a = preferred_a or ["waves", "breath"]
        self.preferred_b = preferred_b or ["breath", "pulse"]
        self.current_a = self.preferred_a[0]
        self.current_b = self.preferred_b[0]
        self.last_switch = time.time()
        self.min_switch_interval = 25.0  # seconds

    def set_preferred(self, patterns_a: List[str], patterns_b: List[str]):
        self.preferred_a = patterns_a
        self.preferred_b = patterns_b

    def apply(self, pattern_a: Optional[str] = None, pattern_b: Optional[str] = None,
              speed: float = 0.9, freq_a: int = 28, freq_b: int = 18):
        if pattern_a:
            self.current_a = pattern_a
            self.controller.set_mode_a(pattern_a, speed=speed, frequency=freq_a)
            log.info("Pattern A → %s", pattern_a)
        if pattern_b:
            self.current_b = pattern_b
            self.controller.set_mode_b(pattern_b, speed=speed, frequency=freq_b)
            log.info("Pattern B → %s", pattern_b)
        self.last_switch = time.time()

    def maybe_auto_switch(self, force: bool = False, aggression: float = 1.0):
        """Character / mood driven automatic switch."""
        now = time.time()
        interval = self.min_switch_interval / max(0.5, aggression)
        if not force and (now - self.last_switch) < interval:
            return

        pa = random.choice(self.preferred_a)
        pb = random.choice(self.preferred_b)
        self.apply(pa, pb)

    def random_mean_pattern(self):
        """For sadistic / event spikes."""
        mean_a = random.choice(["whip", "sting", "climb", "random"])
        mean_b = random.choice(["pulse", "sting", "throb"])
        self.apply(mean_a, mean_b, speed=1.15)
