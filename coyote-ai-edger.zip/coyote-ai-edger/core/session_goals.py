"""
Session goals / win conditions.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

log = logging.getLogger(__name__)


class GoalType(str, Enum):
    EDGE_ONLY = "edge_only"           # alleen edgen, nooit over de rand
    EDGES_THEN_DENIAL = "edges_then_denial"  # N edges, daarna denial
    FORCED = "forced"                 # forced orgasm toegestaan / gewenst
    TRAINING = "training"             # langzaam opbouwen, lange randen
    ENDURANCE = "endurance"           # zo lang mogelijk op de rand


@dataclass
class SessionGoal:
    goal_type: GoalType
    target_edges: int = 3
    max_duration_min: Optional[int] = None
    description: str = ""

    edges_reached: int = 0
    finished: bool = False
    result: str = ""

    def on_edge(self) -> Optional[str]:
        """Called when an edge is detected. Returns instruction or None."""
        self.edges_reached += 1
        log.info("Goal progress: edges=%d / target=%d", self.edges_reached, self.target_edges)

        if self.goal_type == GoalType.EDGE_ONLY:
            return "drop"  # altijd terugtrekken

        if self.goal_type == GoalType.EDGES_THEN_DENIAL:
            if self.edges_reached >= self.target_edges:
                self.finished = True
                self.result = "denial"
                return "deny"
            return "drop"

        if self.goal_type == GoalType.FORCED:
            if self.edges_reached >= self.target_edges:
                self.finished = True
                self.result = "forced"
                return "force"
            return "drop"

        if self.goal_type == GoalType.TRAINING:
            return "drop"

        if self.goal_type == GoalType.ENDURANCE:
            return "hold_near"  # probeer net onder de edge te blijven

        return "drop"

    def status_text(self) -> str:
        return f"{self.goal_type.value} | edges {self.edges_reached}/{self.target_edges}"


def make_goal(name: str, target_edges: int = 3) -> SessionGoal:
    mapping = {
        "edge_only": GoalType.EDGE_ONLY,
        "alleen_edgen": GoalType.EDGE_ONLY,
        "edges_then_denial": GoalType.EDGES_THEN_DENIAL,
        "3_edges_denial": GoalType.EDGES_THEN_DENIAL,
        "forced": GoalType.FORCED,
        "forced_orgasm": GoalType.FORCED,
        "training": GoalType.TRAINING,
        "endurance": GoalType.ENDURANCE,
    }
    gt = mapping.get(name.lower(), GoalType.EDGE_ONLY)
    return SessionGoal(
        goal_type=gt,
        target_edges=target_edges,
        description=name,
    )
