"""
Mood / session progression.
Starts relatively mild and can slowly become more intense or mean
depending on character and time.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass

log = logging.getLogger(__name__)


@dataclass
class MoodState:
    intensity: float = 0.55       # 0.0 – 1.0 overall intensity multiplier
    meanness: float = 0.15        # 0.0 – 1.0 chance bias for mean events
    talk_urge: float = 0.4
    phase: str = "warmup"         # warmup → building → peak → cooldown


class MoodEngine:
    def __init__(self, character_mean_chance: float = 0.08, aggression: float = 1.0):
        self.state = MoodState()
        self.start = time.time()
        self.character_mean = character_mean_chance
        self.aggression = aggression
        self.last_update = time.time()

    def update(self, edges: int = 0, close: bool = False):
        now = time.time()
        elapsed_min = (now - self.start) / 60.0

        # Natural progression
        if elapsed_min < 3:
            self.state.phase = "warmup"
            self.state.intensity = 0.45 + elapsed_min * 0.05
        elif elapsed_min < 12:
            self.state.phase = "building"
            self.state.intensity = min(0.95, 0.55 + (elapsed_min - 3) * 0.04 * self.aggression)
            self.state.meanness = min(0.7, self.character_mean + elapsed_min * 0.015)
        else:
            self.state.phase = "peak"
            self.state.intensity = min(1.0, 0.85 + (elapsed_min - 12) * 0.01)
            self.state.meanness = min(0.85, self.character_mean + 0.25)

        if close:
            self.state.talk_urge = min(1.0, self.state.talk_urge + 0.08)
        else:
            self.state.talk_urge = max(0.2, self.state.talk_urge - 0.01)

        self.last_update = now

    def intensity_multiplier(self) -> float:
        return max(0.3, min(1.3, self.state.intensity))

    def should_do_mean_event(self) -> bool:
        import random
        return random.random() < (self.state.meanness * 0.12)
