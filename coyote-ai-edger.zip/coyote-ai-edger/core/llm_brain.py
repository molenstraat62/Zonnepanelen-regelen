"""
LLM brain – decides what to say.
Backends (in order of preference):
  1. Ollama / local OpenAI-compatible API  (LLM_BACKEND=ollama)
  2. OpenAI cloud                         (LLM_BACKEND=openai + API key)
  3. Rule-based offline fallback
"""

from __future__ import annotations

import logging
import os
import random
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


class LLMBrain:
    def __init__(
        self,
        character,
        memory_context: str = "",
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        backend: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        self.character = character
        self.memory_context = memory_context
        self.history: List[Dict[str, str]] = []

        # Config from env / args / defaults
        self.backend = (backend or os.getenv("LLM_BACKEND") or "auto").lower()
        self.base_url = (
            base_url
            or os.getenv("LLM_BASE_URL")
            or os.getenv("OLLAMA_HOST")
            or "http://127.0.0.1:11434/v1"
        )
        self.api_key = api_key or os.getenv("OPENAI_API_KEY") or "ollama"
        self.model = model or os.getenv("LLM_MODEL") or "llama3.2"

        # auto: try ollama if reachable later, else openai if key looks real
        if self.backend == "auto":
            if os.getenv("OPENAI_API_KEY") and not os.getenv("LLM_BACKEND"):
                # Prefer explicit cloud key only if user set it; still try ollama first offline
                self.backend = "ollama"
            else:
                self.backend = "ollama"

    def _system_prompt(self) -> str:
        return f"""{self.character.system_prompt.strip()}

Je bent de AI die een e-stim sessie (Coyote) bestuurt.
Je krijgt af en toe status-updates (power, of de sub dichtbij is, mood, goal).
Reageer kort (1-2 zinnen). Geef soms een instructie, soms alleen een observatie.
Praat alsof je echt tegen de persoon praat.

Eerdere sessies:
{self.memory_context}
"""

    async def think(self, status: Dict[str, Any]) -> Optional[str]:
        talk_chance = self.character.talkativeness * status.get("talk_urge", 0.4)
        if random.random() > talk_chance and not status.get("force_talk"):
            return None

        prompt = self._build_user_prompt(status)

        if self.backend in ("ollama", "local", "openai"):
            try:
                text = await self._call_chat(prompt)
                if text:
                    self.history.append({"role": "assistant", "content": text})
                    return text
            except Exception as e:
                log.warning("LLM (%s) failed → rule-based: %s", self.backend, e)

        return self._rule_based(status)

    def _build_user_prompt(self, status: Dict[str, Any]) -> str:
        close = "dichtbij de edge" if status.get("close") else "niet kritiek"
        return (
            f"Status: power A={status.get('power_a', 0):.0f} B={status.get('power_b', 0):.0f}, "
            f"fase={status.get('phase', '?')}, edges={status.get('edges', 0)}, "
            f"sub is {close}, goal={status.get('goal', '?')}. "
            f"Eventueel recent event: {status.get('last_event', 'geen')}."
        )

    async def _call_chat(self, user_prompt: str) -> Optional[str]:
        """OpenAI-compatible chat (Ollama or OpenAI cloud)."""
        from openai import AsyncOpenAI

        if self.backend in ("ollama", "local"):
            client = AsyncOpenAI(base_url=self.base_url, api_key=self.api_key or "ollama")
            model = self.model or "llama3.2"
        else:
            client = AsyncOpenAI(api_key=self.api_key)
            model = self.model if self.model and self.model != "llama3.2" else "gpt-4o-mini"

        messages = [
            {"role": "system", "content": self._system_prompt()},
            *self.history[-6:],
            {"role": "user", "content": user_prompt},
        ]
        resp = await client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=80,
            temperature=0.85,
        )
        text = (resp.choices[0].message.content or "").strip()
        return text or None

    def _rule_based(self, status: Dict[str, Any]) -> str:
        close = status.get("close")
        phase = status.get("phase", "")
        edges = status.get("edges", 0)
        cid = getattr(self.character, "id", "") or ""

        if close:
            pool = [
                "Blijf precies daar. Adem. Niet over de rand.",
                "Ik voel dat je dichtbij bent. Nog niet.",
                "Houd het. Goed zo.",
                "Rand. Blijf erop hangen.",
            ]
        elif phase in ("warmup", "calibration"):
            pool = [
                "We warmen rustig op. Laat het toe.",
                "Goed. Ik bouw langzaam op.",
                "Adem mee. Dit is nog maar het begin.",
            ]
        elif edges >= 3:
            pool = [
                f"Al {edges} edges. Je lichaam went — ik duw door.",
                "Je denkt dat je het snapt. Nog een ronde.",
                "Mooi volgehouden. We gaan door.",
            ]
        else:
            pool = [
                "Ik heb de controle. Jij volgt.",
                "Concentreer je op het gevoel.",
                "Nog even zo. Geen haast.",
                "Goed. Laat het bouwen.",
            ]

        # Character flavour
        if "sadistic" in cid:
            pool.append("Je mag best een beetje lijden.")
        if "teasing" in cid:
            pool.append("Bijna… of toch niet.")
        if "clinical" in cid:
            pool.append("Respons genoteerd. We gaan door met het protocol.")

        return random.choice(pool)
