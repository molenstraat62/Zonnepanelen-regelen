"""
Coyote V3 controller – pure bleak implementation.
"""

from __future__ import annotations

import asyncio
import logging
import math
from typing import Optional

from config import (
    MAX_POWER_A,
    MAX_POWER_B,
    DEFAULT_MODE_A,
    DEFAULT_MODE_B,
    DEFAULT_FREQ_A,
    DEFAULT_FREQ_B,
    DEFAULT_SPEED,
    COYOTE_NAME_PREFIX,
)

log = logging.getLogger(__name__)

SERVICE_UUID = "0000180c-0000-1000-8000-00805f9b34fb"
WRITE_UUID   = "0000150a-0000-1000-8000-00805f9b34fb"
NOTIFY_UUID  = "0000150b-0000-1000-8000-00805f9b34fb"


def _freq_to_byte(hz: int) -> int:
    hz = max(10, min(1000, int(hz)))
    if hz <= 100:
        return hz
    if hz <= 600:
        return (hz - 100) // 5 + 100
    return (hz - 600) // 10 + 200


class CoyoteController:
    def __init__(self):
        self._client = None
        self._connected = False
        self._power_a = 0
        self._power_b = 0
        self._freq_a = DEFAULT_FREQ_A
        self._freq_b = DEFAULT_FREQ_B
        self._speed = DEFAULT_SPEED
        self._mode_a = DEFAULT_MODE_A
        self._mode_b = DEFAULT_MODE_B
        self._seq = 1
        self._tick_task: Optional[asyncio.Task] = None
        self._clock = 0.0
        self._soft_a = min(MAX_POWER_A, 40)
        self._soft_b = min(MAX_POWER_B, 35)

    @property
    def connected(self) -> bool:
        return self._connected

    async def connect(self, address: Optional[str] = None, timeout: float = 12.0) -> bool:
        try:
            from bleak import BleakScanner, BleakClient
        except ImportError:
            log.error("bleak not installed: pip install bleak")
            return False

        if address is None:
            log.info("Scanning for Coyote V3 (%s)…", COYOTE_NAME_PREFIX)
            devices = await BleakScanner.discover(timeout=timeout)

            log.info("BLE devices seen (%d):", len(devices))
            for d in devices:
                log.info("  %s  |  %s", d.address, d.name or "(no name)")

            target = None
            for d in devices:
                name = (d.name or "").lower()
                if (
                    (d.name or "").startswith(COYOTE_NAME_PREFIX)
                    or "coyote" in name
                    or "47l121" in name
                    or "47l12" in name
                    or "dg-lab" in name
                    or "dglab" in name
                ):
                    target = d
                    break

            if not target:
                log.error(
                    "No Coyote found.\n"
                    "  1) Verwijder Coyote uit Windows Bluetooth-instellingen\n"
                    "  2) Zet Coyote uit/aan\n"
                    "  3) Sluit DG-Lab app / XToys\n"
                    "  4) Of start met: python main.py --address AA:BB:CC:DD:EE:FF"
                )
                return False
            address = target.address
            log.info("Found Coyote: %s (%s)", target.name, address)

        log.info("Connecting to %s …", address)
        self._client = BleakClient(address)
        try:
            await self._client.connect(timeout=timeout)
        except Exception as e:
            log.error("Connect failed: %s", e)
            log.error(
                "Tip: ontkoppel de Coyote in Windows-instellingen en probeer opnieuw. "
                "Windows 'verbonden' blokkeert vaak BLE-apps."
            )
            return False

        self._connected = True
        await self._send_bf()
        self._tick_task = asyncio.create_task(self._b0_loop())
        log.info("Connected – soft limits set, B0 loop running")
        return True

    async def _send_bf(self):
        sa = min(200, int(self._soft_a * 2))
        sb = min(200, int(self._soft_b * 2))
        pkt = bytes([0xBF, sa, sb, 0, 0, 0, 0])
        try:
            await self._client.write_gatt_char(WRITE_UUID, pkt, response=False)
        except Exception as e:
            log.warning("BF write failed: %s", e)

    def set_power(self, power_a: float, power_b: float) -> None:
        if not self._connected:
            return
        self._power_a = max(0, min(int(power_a), MAX_POWER_A))
        self._power_b = max(0, min(int(power_b), MAX_POWER_B))

    def set_mode_a(self, mode: str, speed: float = 1.0, frequency: int = 25) -> None:
        self._mode_a = mode
        self._speed = speed
        self._freq_a = frequency

    def set_mode_b(self, mode: str, speed: float = 1.0, frequency: int = 20) -> None:
        self._mode_b = mode
        self._freq_b = frequency

    def emergency_stop(self) -> None:
        self._power_a = 0
        self._power_b = 0
        log.warning("EMERGENCY STOP")

    async def disconnect(self) -> None:
        self._power_a = 0
        self._power_b = 0
        if self._tick_task:
            self._tick_task.cancel()
            try:
                await self._tick_task
            except asyncio.CancelledError:
                pass
            self._tick_task = None
        if self._client and self._client.is_connected:
            try:
                await self._write_b0(0, 0)
                await self._client.disconnect()
            except Exception as e:
                log.debug("Disconnect: %s", e)
        self._connected = False
        self._client = None
        log.info("Disconnected")

    def _pattern_frames(self, mode: str, freq: int, power_scale: float, t: float):
        fb = _freq_to_byte(freq)
        base = max(0, min(100, int(power_scale)))

        def wave(phase):
            return int(base * (0.55 + 0.45 * math.sin(phase)))

        if mode in ("breath", "waves"):
            env = 0.5 + 0.5 * math.sin(t * 1.2 * self._speed)
            vals = [int(base * env)] * 4
        elif mode == "pulse":
            vals = [base, 0, base, 0]
        elif mode == "climb":
            vals = [int(base * 0.4), int(base * 0.6), int(base * 0.8), base]
        elif mode == "hold":
            vals = [base] * 4
        elif mode in ("whip", "sting"):
            vals = [0, 0, base, int(base * 0.3)]
        elif mode == "tickle":
            vals = [int(base * 0.3), base, int(base * 0.3), base]
        elif mode == "throb":
            vals = [wave(t + i * 0.4) for i in range(4)]
        elif mode == "random":
            import random
            vals = [int(base * random.uniform(0.2, 1.0)) for _ in range(4)]
        else:
            vals = [base] * 4

        return [fb] * 4, [max(0, min(100, v)) for v in vals]

    async def _write_b0(self, pa: int, pb: int):
        if not self._client or not self._connected:
            return
        dev_a = max(0, min(200, pa * 2))
        dev_b = max(0, min(200, pb * 2))
        seq = self._seq & 0x0F
        self._seq = (self._seq + 1) & 0x0F
        header2 = (seq << 4) | 0x0F
        t = self._clock
        fa, ia = self._pattern_frames(self._mode_a, self._freq_a, pa, t)
        fb, ib = self._pattern_frames(self._mode_b, self._freq_b, pb, t + 0.3)
        pkt = bytearray(20)
        pkt[0] = 0xB0
        pkt[1] = header2
        pkt[2] = dev_a
        pkt[3] = dev_b
        pkt[4:8] = bytes(fa)
        pkt[8:12] = bytes(ia)
        pkt[12:16] = bytes(fb)
        pkt[16:20] = bytes(ib)
        try:
            await self._client.write_gatt_char(WRITE_UUID, bytes(pkt), response=False)
        except Exception as e:
            log.debug("B0 write error: %s", e)

    async def _b0_loop(self):
        try:
            while self._connected:
                await self._write_b0(self._power_a, self._power_b)
                self._clock += 0.1 * self._speed
                await asyncio.sleep(0.1)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            log.error("B0 loop error: %s", e)
