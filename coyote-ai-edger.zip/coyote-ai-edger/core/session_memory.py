"""
Simple session memory – remembers previous sessions.
Stored as JSON in memory/ folder.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


class SessionMemory:
    def __init__(self, memory_dir: str = "memory"):
        self.dir = Path(memory_dir)
        self.dir.mkdir(exist_ok=True)
        self.file = self.dir / "history.json"
        self.history: List[Dict[str, Any]] = []
        self._load()

    def _load(self):
        if self.file.exists():
            try:
                self.history = json.loads(self.file.read_text(encoding="utf-8"))
            except Exception as e:
                log.warning("Could not load memory: %s", e)
                self.history = []

    def _save(self):
        self.file.write_text(json.dumps(self.history, indent=2, ensure_ascii=False), encoding="utf-8")

    def add_session(self, summary: Dict[str, Any]):
        entry = {
            "date": datetime.now().isoformat(timespec="seconds"),
            **summary,
        }
        self.history.append(entry)
        # keep last 30
        self.history = self.history[-30:]
        self._save()
        log.info("Session saved to memory")

    def last_sessions(self, n: int = 5) -> List[Dict[str, Any]]:
        return self.history[-n:]

    def average_edges(self) -> float:
        if not self.history:
            return 0.0
        edges = [s.get("edges", 0) for s in self.history]
        return sum(edges) / len(edges)

    def suggested_base_adjustment(self) -> float:
        """
        Rough heuristic: if recent sessions had very few edges,
        maybe base was too low / too high. Returns a multiplier.
        """
        recent = self.last_sessions(3)
        if len(recent) < 2:
            return 1.0
        avg = sum(s.get("edges", 0) for s in recent) / len(recent)
        if avg < 1.5:
            return 0.92  # slightly lower next time
        if avg > 6:
            return 1.08
        return 1.0

    def context_for_llm(self) -> str:
        if not self.history:
            return "Geen eerdere sessies bekend."
        lines = []
        for s in self.last_sessions(3):
            lines.append(
                f"- {s.get('date','?')[:10]}: {s.get('duration_sec',0)/60:.0f} min, "
                f"{s.get('edges',0)} edges, goal={s.get('goal','?')}, "
                f"character={s.get('character','?')}"
            )
        return "Recente sessies:\n" + "\n".join(lines)
