"""
Calibration with multiple modes + slower, more accurate ramp.
Modes:
  both          – A and B together
  a_only        – only channel A
  b_only        – only channel B
  alternate     – alternate A-focus / B-focus steps
  pattern_focus – ramp while switching patterns
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Callable, Optional

from config import (
    CALIBRATION_START_POWER,
    CALIBRATION_STEP,
    CALIBRATION_STEP_INTERVAL,
    CALIBRATION_MAX_TEST,
    MAX_POWER_A,
    MAX_POWER_B,
)

log = logging.getLogger(__name__)

CAL_MODES = ("both", "a_only", "b_only", "alternate", "pattern_focus")


class Calibrator:
    def __init__(
        self,
        controller,
        on_enough: Optional[Callable[[], None]] = None,
        pattern_manager=None,
    ):
        self.controller = controller
        self.on_enough = on_enough
        self.pattern_manager = pattern_manager
        self.enough_signaled = False
        self.final_a = 0.0
        self.final_b = 0.0
        self._running = False
        self.mode = "both"
        # finer default steps (can be overridden)
        self.start_power = float(CALIBRATION_START_POWER)
        self.step = max(0.8, float(CALIBRATION_STEP) * 0.7)  # finer than before
        self.interval = max(2.8, float(CALIBRATION_STEP_INTERVAL))
        self.max_test = float(CALIBRATION_MAX_TEST)

    def signal_enough(self) -> None:
        if self._running:
            log.info("Calibration: ENOUGH")
            self.enough_signaled = True
            if self.on_enough:
                self.on_enough()

    async def run(self, mode: str = "both") -> tuple[float, float]:
        self.mode = mode if mode in CAL_MODES else "both"
        self._running = True
        self.enough_signaled = False
        power = self.start_power
        step_i = 0

        log.info("=" * 50)
        log.info("CALIBRATION START  mode=%s", self.mode)
        log.info("Langzame opbouw. Druk E / dashboard GENOEG als het genoeg is.")
        log.info("=" * 50)

        self.controller.set_power(0, 0)
        await asyncio.sleep(0.8)

        last_a, last_b = 0.0, 0.0
        try:
            while self._running and not self.enough_signaled:
                if power > self.max_test:
                    log.warning("Calibration max bereikt")
                    break

                pa, pb = self._powers_for_step(power, step_i)
                pa = min(pa, MAX_POWER_A)
                pb = min(pb, MAX_POWER_B)
                last_a, last_b = pa, pb

                if self.mode == "pattern_focus" and self.pattern_manager and step_i % 2 == 0:
                    self.pattern_manager.maybe_auto_switch(force=True, aggression=1.2)

                self.controller.set_power(pa, pb)
                log.info("Cal %s → A=%.1f  B=%.1f", self.mode, pa, pb)

                start = time.time()
                while time.time() - start < self.interval:
                    if self.enough_signaled or not self._running:
                        break
                    await asyncio.sleep(0.08)

                power += self.step
                step_i += 1
        finally:
            self._running = False

        # Slightly below "enough" point
        self.final_a = max(6.0, last_a * 0.90)
        self.final_b = max(5.0, last_b * 0.90)
        if self.mode == "a_only":
            self.final_b = max(5.0, self.final_a * 0.75)
        if self.mode == "b_only":
            self.final_a = max(6.0, self.final_b * 1.1)

        self.controller.set_power(0, 0)
        await asyncio.sleep(1.0)
        log.info("Calibration done → base A=%.1f  B=%.1f", self.final_a, self.final_b)
        return self.final_a, self.final_b

    def _powers_for_step(self, power: float, step_i: int) -> tuple[float, float]:
        if self.mode == "a_only":
            return power, 0.0
        if self.mode == "b_only":
            return 0.0, power * 0.9
        if self.mode == "alternate":
            if step_i % 2 == 0:
                return power, max(3.0, power * 0.35)
            return max(3.0, power * 0.35), power * 0.9
        # both + pattern_focus
        return power, power * 0.85

    def stop(self) -> None:
        self._running = False
        self.controller.set_power(0, 0)
