"""
Two-way speech conversation loop.
Listens → transcribes → LLM (in character) → TTS reply.
"""

from __future__ import annotations

import asyncio
import json
import logging
import queue
import threading
import time
from typing import Callable, Optional

log = logging.getLogger(__name__)


class ConversationLoop:
    """
    Continuous listen → think → speak cycle.
    Can run alongside the main control loop.
    """

    def __init__(
        self,
        brain,          # LLMBrain
        tts,            # TTS
        on_user_text: Optional[Callable[[str], None]] = None,
        model_path: str = "model",
        sample_rate: int = 16000,
    ):
        self.brain = brain
        self.tts = tts
        self.on_user_text = on_user_text
        self.model_path = model_path
        self.sample_rate = sample_rate
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self.enabled = True

    def start(self, loop: asyncio.AbstractEventLoop):
        self._loop = loop
        self._running = True
        self._thread = threading.Thread(target=self._listen_thread, daemon=True)
        self._thread.start()
        log.info("Two-way conversation started")

    def stop(self):
        self._running = False

    def _listen_thread(self):
        try:
            import sounddevice as sd
            from vosk import Model, KaldiRecognizer
        except ImportError:
            log.error("vosk/sounddevice required for conversation")
            return

        try:
            model = Model(self.model_path)
        except Exception as e:
            log.error("Vosk model load failed: %s", e)
            return

        rec = KaldiRecognizer(model, self.sample_rate)
        rec.SetWords(True)
        q: queue.Queue = queue.Queue()

        def callback(indata, frames, time_info, status):
            q.put(bytes(indata))

        try:
            with sd.RawInputStream(
                samplerate=self.sample_rate,
                blocksize=8000,
                dtype="int16",
                channels=1,
                callback=callback,
            ):
                while self._running:
                    try:
                        data = q.get(timeout=0.4)
                    except queue.Empty:
                        continue

                    if rec.AcceptWaveform(data):
                        result = json.loads(rec.Result())
                        text = (result.get("text") or "").strip()
                        if text and len(text) > 2:
                            log.info("User said: %s", text)
                            if self.on_user_text:
                                self.on_user_text(text)
                            # Schedule async reply on main loop
                            if self._loop and self._loop.is_running():
                                asyncio.run_coroutine_threadsafe(
                                    self._reply(text), self._loop
                                )
        except Exception as e:
            log.error("Conversation listen error: %s", e)

    async def _reply(self, user_text: str):
        if not self.enabled:
            return
        # Feed user text into brain history and get a reply
        status = {
            "force_talk": True,
            "user_said": user_text,
            "phase": "conversation",
            "talk_urge": 1.0,
            "close": False,
            "power_a": 0,
            "power_b": 0,
            "edges": 0,
            "goal": "",
        }
        # Add user message to history so LLM can respond in context
        self.brain.history.append({"role": "user", "content": user_text})
        reply = await self.brain.think(status)
        if reply:
            log.info("AI replies: %s", reply)
            await self.tts.say(reply)
