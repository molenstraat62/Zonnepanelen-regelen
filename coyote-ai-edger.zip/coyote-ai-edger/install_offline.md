# Offline installatie

## Python-versie

Deze `wheels/` map is voor **Windows 64-bit + Python 3.12**.

```bat
python --version
```
Moet 3.12.x zijn.

## Install

```bat
python -m venv .venv
.\.venv\Scripts\activate

python -m pip install --no-index --find-links=.\wheels -r requirements.txt
```

Als aiohttp of iets anders faalt:

```bat
python -m pip install --no-index --find-links=.\wheels bleak keyboard python-dotenv edge-tts fastapi uvicorn openai websockets aiohttp
```
