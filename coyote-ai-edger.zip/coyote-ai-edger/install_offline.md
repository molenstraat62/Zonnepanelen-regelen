# Offline install – Python 3.12 Windows 64-bit

Wheels include **winrt** (needed by bleak on Windows).

```bat
python --version
```
Must show 3.12.x

```bat
.\install_offline.bat
```

Or:

```bat
python -m pip install --no-index --find-links=.\wheels winrt-runtime
python -m pip install --no-index --find-links=.\wheels -r requirements.txt
python -m pip install --no-index --find-links=.\wheels winrt-windows-devices-bluetooth winrt-windows-foundation winrt-windows-foundation-collections winrt-windows-devices-enumeration winrt-windows-devices-radios winrt-windows-storage-streams winrt-windows-devices-bluetooth-advertisement winrt-windows-devices-bluetooth-genericattributeprofile
```

Check:

```bat
dir wheels\*winrt_runtime*
python -c "import bleak, winrt.runtime; print('ok')"
```
