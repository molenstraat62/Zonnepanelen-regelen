#!/usr/bin/env python3
"""
Coyote AI Edger – full system
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import threading
import time
from typing import Optional

from config import (
    CONTROL_LOOP_HZ,
    CALIBRATION_ENABLED,
    DEFAULT_CHARACTER,
    DEFAULT_GOAL,
    DEFAULT_TARGET_EDGES,
    TTS_ENABLED,
    TTS_VOICE,
    LLM_MODEL,
    LLM_BACKEND,
    LLM_BASE_URL,
)
from characters import get_character, list_characters
from core import CoyoteController, AdaptiveEdger, Calibrator
from core.pattern_manager import PatternManager
from core.session_logger import SessionLogger
from core.session_goals import make_goal
from core.mood import MoodEngine
from core.events import EventEngine
from core.session_memory import SessionMemory
from core.llm_brain import LLMBrain
from core.tts import TTS
from core.conversation import ConversationLoop
from core.funscript import FunscriptPlayer
from devices.lovense import LovenseEdge
from feedback import KeyboardFeedback, SpeechFeedback, CivetFeedback
from utils.safety import install_sigint_handler
from characters import CHARACTERS
import queue


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("main")


def parse_args():
    p = argparse.ArgumentParser(description="Coyote AI Edger")
    p.add_argument("--character", "-c", default=DEFAULT_CHARACTER)
    p.add_argument("--goal", "-g", default=DEFAULT_GOAL)
    p.add_argument("--edges", type=int, default=DEFAULT_TARGET_EDGES)
    p.add_argument("--no-cal", action="store_true")
    p.add_argument("--speech", action="store_true", help="Keyword speech feedback")
    p.add_argument("--conversation", action="store_true", help="Two-way speech conversation")
    p.add_argument("--civet", action="store_true")
    p.add_argument("--lovense", action="store_true", help="Also control Lovense Edge 2")
    p.add_argument("--funscript", type=str, default=None, help="Path to .funscript to play")
    p.add_argument("--web", action="store_true", help="Start local web dashboard")
    p.add_argument("--web-port", type=int, default=8765)
    p.add_argument("--no-keyboard", action="store_true")
    p.add_argument("--no-tts", action="store_true")
    p.add_argument("--list-characters", action="store_true")
    p.add_argument("--address", type=str, default=None,
                   help="Coyote BLE address, e.g. AA:BB:CC:DD:EE:FF (skip scan)")
    return p.parse_args()


def start_web(port: int, command_queue):
    try:
        import websockets  # noqa: F401
    except ImportError:
        log.warning("pip install websockets  — anders blijft dashboard beperkt")
    import uvicorn
    from web.server import app, set_command_handler, update_state

    def handle_cmd(cmd, payload):
        command_queue.put((cmd, payload))

    set_command_handler(handle_cmd)
    # seed character list for UI
    update_state(
        characters=[{"id": c.id, "name": c.name} for c in CHARACTERS.values()],
    )

    def run():
        uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")

    t = threading.Thread(target=run, daemon=True)
    t.start()
    log.info("Web dashboard → http://127.0.0.1:%d", port)
    return t



async def push_web(**kwargs):
    try:
        from web.server import update_state, push_state
        update_state(**kwargs)
        await push_state()
    except Exception:
        pass


async def run_session(args):
    if args.list_characters:
        for c in list_characters():
            print(f"  {c.id:22} {c.name:22} {c.description[:60]}")
        return

    character = get_character(args.character)
    goal = make_goal(args.goal, target_edges=args.edges)
    memory = SessionMemory()
    slog = SessionLogger()
    web_commands: queue.Queue = queue.Queue()
    cal_mode = "both"
    # flags controlled by web / keyboard
    request_start_cal = False
    request_start_session = False
    skip_cal_flag = args.no_cal

    if args.web:
        start_web(args.web_port, web_commands)

    log.info("=" * 55)
    log.info("Character : %s", character.name)
    log.info("Goal      : %s (edges=%d)", goal.goal_type.value, goal.target_edges)
    log.info("=" * 55)

    controller = CoyoteController()
    edger = AdaptiveEdger(controller)
    edger.edge_drop_factor = character.edge_drop_factor  # type: ignore
    calibrator = Calibrator(controller)
    patterns = PatternManager(controller, character.preferred_patterns_a, character.preferred_patterns_b)
    calibrator.pattern_manager = patterns
    mood = MoodEngine(character.mean_chance, character.ramp_aggression)
    events = EventEngine(patterns, edger, slog)
    brain = LLMBrain(
        character,
        memory_context=memory.context_for_llm(),
        model=LLM_MODEL,
        backend=LLM_BACKEND,
        base_url=LLM_BASE_URL,
    )
    tts = TTS(voice=getattr(character, "tts_voice", None) or TTS_VOICE,
              enabled=TTS_ENABLED and not args.no_tts)

    lovense: Optional[LovenseEdge] = None
    if args.lovense:
        lovense = LovenseEdge()

    funscript: Optional[FunscriptPlayer] = None
    if args.funscript:
        funscript = FunscriptPlayer(controller, channel="both")
        if not funscript.load(args.funscript):
            funscript = None

    stop_requested = False
    last_event_name = ""

    def on_close(is_close: bool):
        edger.on_feedback(is_close)
        if is_close:
            slog.edge()
            instruction = goal.on_edge()
            if instruction == "force" and character.force_allowed:
                log.warning("GOAL: force")
            elif instruction == "deny":
                edger.on_feedback(True)

    def on_enough():
        calibrator.signal_enough()

    def on_stop():
        nonlocal stop_requested
        stop_requested = True
        edger.stop()
        calibrator.stop()
        if funscript:
            funscript.stop()

    fbs = []
    if not args.no_keyboard:
        fbs.append(KeyboardFeedback(on_close, on_stop, on_enough))
    if args.speech and not args.conversation:
        fbs.append(SpeechFeedback(on_close, on_stop, on_enough))

    civet = CivetFeedback(on_close) if args.civet else None
    install_sigint_handler(on_stop)

    if not await controller.connect(address=args.address):
        log.error("Coyote not found")
        return

    if civet and not await civet.connect():
        civet = None

    if lovense:
        ok = await lovense.connect()
        if not ok:
            log.warning("Lovense not available – continuing without")
            lovense = None

    for fb in fbs:
        fb.start()
    await tts.start()

    # Two-way conversation
    convo = None
    if args.conversation:
        convo = ConversationLoop(brain, tts, on_user_text=lambda t: slog.event("user_said", text=t))
        convo.start(asyncio.get_running_loop())

    try:
        await push_web(
            connected=True,
            phase="idle",
            character=character.name,
            character_id=character.id,
            goal=goal.status_text(),
            cal_mode=cal_mode,
            running=False,
        )

        async def drain_web_pre():
            nonlocal character, goal, cal_mode, skip_cal_flag, request_start_cal
            try:
                while True:
                    cmd, payload = web_commands.get_nowait()
                    if cmd == "set_config":
                        cid = payload.get("character")
                        if cid:
                            character = get_character(cid)
                            edger.edge_drop_factor = character.edge_drop_factor
                            patterns.set_preferred(character.preferred_patterns_a, character.preferred_patterns_b)
                            brain.character = character
                        if payload.get("goal"):
                            goal = make_goal(payload["goal"], target_edges=args.edges)
                        if payload.get("cal_mode"):
                            cal_mode = payload["cal_mode"]
                    elif cmd == "start_calibration":
                        cal_mode = payload.get("mode") or cal_mode
                        request_start_cal = True
                    elif cmd == "cal_skip":
                        skip_cal_flag = True
                        request_start_cal = True
                    elif cmd == "stop":
                        on_stop()
                    elif cmd == "edge":
                        on_close(bool(payload.get("close")))
                    elif cmd == "cal_enough":
                        on_enough()
            except queue.Empty:
                pass

        # With --web: wait until user starts cal/session from dashboard (or 3s auto)
        if args.web and not skip_cal_flag and not funscript:
            log.info("Dashboard ready — kies karakter/modus en start calibratie of sessie")
            wait_deadline = asyncio.get_event_loop().time() + 120
            while not stop_requested and not request_start_cal and not skip_cal_flag:
                await drain_web_pre()
                await push_web(
                    connected=True, phase="idle", character=character.name,
                    character_id=character.id, goal=goal.status_text(),
                    cal_mode=cal_mode, running=False,
                )
                if asyncio.get_event_loop().time() > wait_deadline:
                    log.info("Timeout — start calibratie automatisch")
                    request_start_cal = True
                    break
                await asyncio.sleep(0.25)

        async def _cal_push():
            while not stop_requested:
                await push_web(
                    power_a=getattr(controller, "_power_a", 0),
                    power_b=getattr(controller, "_power_b", 0),
                    phase="calibration",
                    running=True,
                    character=character.name,
                    character_id=character.id,
                    goal=goal.status_text(),
                    connected=True,
                    cal_mode=cal_mode,
                )
                await drain_web_pre()
                await asyncio.sleep(0.35)

        cal_push_task = None
        do_cal = (
            CALIBRATION_ENABLED and not skip_cal_flag and not funscript
            and (not args.web or request_start_cal or not args.no_cal)
            and not args.no_cal
        )
        if do_cal and not skip_cal_flag:
            cal_push_task = asyncio.create_task(_cal_push())
            base_a, base_b = await calibrator.run(mode=cal_mode)
            if cal_push_task:
                cal_push_task.cancel()
                try:
                    await cal_push_task
                except asyncio.CancelledError:
                    pass
            soft_a = base_a * character.soft_limit_factor
            soft_b = base_b * character.soft_limit_factor
            adj = memory.suggested_base_adjustment()
            edger.set_bases(base_a * adj, base_b * adj, soft_a, soft_b)
        else:
            log.info("Calibration skipped")

        if stop_requested:
            return

        patterns.apply(character.preferred_patterns_a[0], character.preferred_patterns_b[0])
        slog.goal(goal.goal_type.value)
        slog.event("character", id=character.id)

        if funscript:
            funscript.start(loop=True)
            log.info("Funscript mode active")
        else:
            edger.start()

        await push_web(
            running=True,
            character=character.name,
            goal=goal.status_text(),
            phase="warmup",
        )

        opening = await brain.think({
            "force_talk": True, "phase": "warmup", "edges": 0, "close": False,
            "power_a": 0, "power_b": 0, "goal": goal.status_text(), "talk_urge": 1.0,
        })
        if opening:
            slog.say(opening, character.name)
            await tts.say(opening)
            await push_web(last_line=opening)

        interval = 1.0 / CONTROL_LOOP_HZ
        last_talk = time.time()
        last_pattern_check = time.time()

        while controller.connected and not stop_requested and not goal.finished:
            # --- web commands ---
            try:
                while True:
                    cmd, payload = web_commands.get_nowait()
                    if cmd == "edge":
                        on_close(bool(payload.get("close")))
                    elif cmd == "cal_enough":
                        on_enough()
                    elif cmd == "stop":
                        on_stop()
                    elif cmd == "start_calibration":
                        cal_mode = payload.get("mode") or cal_mode
                        log.info("Web: start calibration mode=%s", cal_mode)
                    elif cmd == "cal_skip":
                        skip_cal_flag = True
                        on_enough()
                    elif cmd == "start_session":
                        request_start_session = True
                    elif cmd == "set_config":
                        cid = payload.get("character")
                        if cid:
                            try:
                                character = get_character(cid)
                                edger.edge_drop_factor = character.edge_drop_factor
                                patterns.set_preferred(character.preferred_patterns_a, character.preferred_patterns_b)
                                brain.character = character
                                log.info("Character → %s", character.name)
                            except Exception as e:
                                log.warning("Character switch failed: %s", e)
                        gid = payload.get("goal")
                        if gid:
                            goal = make_goal(gid, target_edges=args.edges)
                            slog.goal(goal.goal_type.value)
                        if payload.get("cal_mode"):
                            cal_mode = payload["cal_mode"]
            except queue.Empty:
                pass


            if funscript:
                if not funscript.tick():
                    break
            else:
                edger.tick()

            mood.update(edges=goal.edges_reached, close=edger.close)

            # Sync Lovense roughly to channel A intensity
            if lovense and lovense.connected:
                strength = min(1.0, edger.current_a / 40.0) if not funscript else 0.5
                await lovense.set_vibrate(strength)

            if not funscript:
                if mood.should_do_mean_event() or (time.time() - events.last_event > 70):
                    ev = events.maybe_trigger(mood.state.meanness)
                    if ev:
                        last_event_name = ev

                if time.time() - last_pattern_check > 30:
                    patterns.maybe_auto_switch(aggression=character.ramp_aggression)
                    last_pattern_check = time.time()

            # Periodic AI talk (skip if in active conversation mode and user just spoke)
            if not args.conversation and time.time() - last_talk > 18:
                status = {
                    "power_a": edger.current_a,
                    "power_b": edger.current_b,
                    "close": edger.close,
                    "phase": mood.state.phase,
                    "edges": goal.edges_reached,
                    "goal": goal.status_text(),
                    "talk_urge": mood.state.talk_urge,
                    "last_event": last_event_name,
                }
                line = await brain.think(status)
                if line:
                    slog.say(line, character.name)
                    await tts.say(line)
                    await push_web(last_line=line)
                    last_talk = time.time()
                    last_event_name = ""

            await push_web(
                power_a=edger.current_a,
                power_b=edger.current_b,
                close=edger.close,
                edges=goal.edges_reached,
                phase=mood.state.phase,
                mood_intensity=mood.state.intensity,
                desense=edger.desense_factor,
                running=True,
                goal=goal.status_text(),
                character=character.name,
                character_id=character.id,
                connected=controller.connected,
                cal_mode=cal_mode,
            )

            await asyncio.sleep(interval)

        summary = slog.summary()
        summary.update({
            "character": character.id,
            "goal": goal.goal_type.value,
            "goal_result": goal.result,
            "edges": goal.edges_reached,
        })
        memory.add_session(summary)
        log.info("Summary: %s", summary)

        closing = await brain.think({
            "force_talk": True, "phase": "cooldown", "edges": goal.edges_reached,
            "close": False, "power_a": 0, "power_b": 0, "goal": goal.status_text(), "talk_urge": 1.0,
        })
        if closing:
            await tts.say(closing)

    finally:
        for fb in fbs:
            fb.stop()
        if convo:
            convo.stop()
        edger.stop()
        if funscript:
            funscript.stop()
        await tts.stop()
        if lovense:
            await lovense.disconnect()
        if civet:
            await civet.disconnect()
        await controller.disconnect()
        await push_web(running=False, power_a=0, power_b=0)
        log.info("Session ended.")


if __name__ == "__main__":
    args = parse_args()
    try:
        asyncio.run(run_session(args))
    except KeyboardInterrupt:
        pass
